<?php
return [
    'img_path'=>'/wine/photo',
    'pwd_pre'=>'wineAdmin_for_fun',
    'adminEmail' => 'admin@example.com',
    'intro'=>'欢迎进入双天酒后台管理系统',
];
