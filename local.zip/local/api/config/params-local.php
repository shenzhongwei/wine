<?php
return [
    'img_path'=>'localhost/wine/photo',
    'pwd_pre' =>'wineUser_shante',
    'pageSize'=>10,
    'servicePhone'=>'4007108888'
];
